from pptx import Presentation
from pptx.util import Inches
import os

prs = Presentation()

# Title Slide
slide_layout = prs.slide_layouts[0]
slide = prs.slides.add_slide(slide_layout)
title = slide.shapes.title
subtitle = slide.placeholders[1]
title.text = "Climate Anomaly Forecasting using Bayesian DBN & ERA5 Data"
subtitle.text = "Anto Rishath A · Team 19 · Amrita Vishwa Vidyapeetham"

# ... (all earlier slides as before)

# Results (Visuals) - use blank layout
blank_layout = prs.slide_layouts[6]  # blank
slide = prs.slides.add_slide(blank_layout)

# Add title manually
left, top, width, height = Inches(0.5), Inches(0.3), Inches(9), Inches(1)
title_box = slide.shapes.add_textbox(left, top, width, height)
title_tf = title_box.text_frame
title_tf.text = "Results (Visuals)"

# Add description
left, top, width, height = Inches(0.5), Inches(1.0), Inches(9), Inches(1)
desc_box = slide.shapes.add_textbox(left, top, width, height)
desc_tf = desc_box.text_frame
desc_tf.text = "Reliability curve and sample maps."

# Insert images
figures_path = "figures"
images_to_add = ["reliability_curve.png", "sample_000_maps.png", "sample_001_maps.png", "sample_002_maps.png"]
left = Inches(0.5)
top = Inches(2)
height = Inches(2)

for i, img in enumerate(images_to_add):
    img_path = os.path.join(figures_path, img)
    if os.path.exists(img_path):
        slide.shapes.add_picture(
            img_path,
            left + Inches((i % 2) * 4.5),
            top + Inches((i // 2) * 2.5),
            height=height
        )

# Save PPT
ppt_path = "/mnt/data/Climate_Anomaly_DBM_Results.pptx"
prs.save(ppt_path)

ppt_path
