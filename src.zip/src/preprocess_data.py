#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Robust ERA5 preprocessing for NetCDF/NetCDF4 files.

- Detects time/lat/lon dimension names automatically.
- Works with variables shaped (time, lat, lon) or (lat, lon).
- Builds (X, y) windows for sequence modeling with --seq_len.
- Saves:
  * data_raw/era5_preprocessed.npz      (clean time series array [T, H, W])
  * data_processed/train_val.npz        (X_train, y_train, X_val, y_val)
"""

import argparse
import os
from typing import Optional, Tuple

import numpy as np
import xarray as xr


def find_dim_names(dims: Tuple[str, ...]) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Return (time_dim, lat_dim, lon_dim) best guesses present in dims."""
    time_candidates = ("time", "valid_time", "initial_time0_hours", "forecast_time", "step")
    lat_candidates = ("latitude", "lat", "y")
    lon_candidates = ("longitude", "lon", "x")

    def first_present(cands):
        for c in cands:
            if c in dims:
                return c
        return None

    t = first_present(time_candidates)
    la = first_present(lat_candidates)
    lo = first_present(lon_candidates)
    return t, la, lo


def choose_variable(ds: xr.Dataset, specified: Optional[str]) -> xr.DataArray:
    """Pick a data variable to process."""
    if specified is not None:
        if specified in ds.data_vars:
            da = ds[specified]
        else:
            raise ValueError(f"--var '{specified}' not found. Available: {list(ds.data_vars)}")
    else:
        # choose first numeric 2D/3D field
        da = None
        for v in ds.data_vars:
            dv = ds[v]
            if dv.dtype.kind in ("i", "u", "f") and 2 <= dv.ndim <= 3:
                da = dv
                break
        if da is None:
            raise ValueError("No suitable numeric 2D/3D variable found. Use --var to specify.")
        print(f"[info] Using variable: {da.name}")
    return da


def open_dataset_netcdf(path: str, engine: Optional[str]) -> Tuple[xr.Dataset, str]:
    """Open a dataset forcing NetCDF engines (no cfgrib here)."""
    tried = []
    engines = [engine] if engine else ["netcdf4", "scipy"]
    last_err = None
    for eng in engines:
        try:
            ds = xr.open_dataset(path, engine=eng)
            return ds, eng
        except Exception as e:
            tried.append((eng, repr(e)))
            last_err = e
    msg = [f"Failed to open '{path}'. Tried engines:"]
    for eng, err in tried:
        msg.append(f"  - [{eng}] {err}")
    raise RuntimeError("\n".join(msg)) from last_err


def to_time_lat_lon(da: xr.DataArray) -> xr.DataArray:
    """Transpose to (time, lat, lon) if time exists; else (lat, lon)."""
    dims = da.dims
    t, la, lo = find_dim_names(dims)
    if la is None or lo is None:
        raise ValueError(f"Could not find latitude/longitude dims in {dims}.")
    if t is not None and t in dims:
        desired = (t, la, lo)
    else:
        # purely spatial
        desired = (la, lo)

    # Only transpose if needed
    if tuple(dims) != tuple(desired):
        # Keep only present dims in desired order
        desired_present = tuple([d for d in desired if d in dims])
        da = da.transpose(*desired_present)
    return da


def standardize_time_series(arr3d: np.ndarray) -> np.ndarray:
    """
    Standardize over time at each grid point: (x - mean_t) / std_t.
    arr3d: [T, H, W]
    """
    mean_t = arr3d.mean(axis=0, keepdims=True)
    std_t = arr3d.std(axis=0, keepdims=True) + 1e-8
    z = (arr3d - mean_t) / std_t
    return z


def build_windows(series3d: np.ndarray, seq_len: int) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build (X,y) from [T, H, W].
    X: [N, seq_len, H, W], y: [N, H, W], where N = T - seq_len
    """
    T, H, W = series3d.shape
    if T <= seq_len:
        raise ValueError(f"Not enough timesteps T={T} for seq_len={seq_len}.")
    N = T - seq_len
    X = np.zeros((N, seq_len, H, W), dtype=series3d.dtype)
    y = np.zeros((N, H, W), dtype=series3d.dtype)
    for i in range(N):
        X[i] = series3d[i:i+seq_len]
        y[i] = series3d[i+seq_len]
    return X, y


def preprocess_era5(input_nc: str, output_npz: str, seq_len: int, var_name: Optional[str], engine: Optional[str]) -> None:
    print(f"Loading data from {input_nc} ...")
    ds, used_engine = open_dataset_netcdf(input_nc, engine)
    print(f"Opened with engine: {used_engine}")

    da = choose_variable(ds, var_name)
    da = to_time_lat_lon(da)

    if da.ndim == 2:
        # single snapshot; make pseudo-time of length 1
        arr = da.values[None, ...]  # [1,H,W]
        print("[warn] Variable has no time dimension; created a single-step series.")
    else:
        arr = da.values  # [T,H,W]

    # Ensure float32 to keep files light
    arr = np.asarray(arr, dtype=np.float32)

    # Save the raw series for inspection / reuse
    os.makedirs(os.path.dirname(output_npz), exist_ok=True)
    np.savez_compressed(output_npz, series=arr)
    print(f"[ok] Saved raw series to: {output_npz}  shape={arr.shape}")

    # If there is a time axis, build windows and split
    if arr.shape[0] >= 2:
        z = standardize_time_series(arr)  # [T,H,W] z-score over time
        X, y = build_windows(z, seq_len)

        # 80/20 split by time order
        N = X.shape[0]
        split = int(0.8 * N)
        X_train, y_train = X[:split], y[:split]
        X_val, y_val = X[split:], y[split:]

        out2 = os.path.join("data_processed", "train_val.npz")
        os.makedirs(os.path.dirname(out2), exist_ok=True)
        np.savez_compressed(out2, X_train=X_train, y_train=y_train, X_val=X_val, y_val=y_val)
        print(f"[ok] Saved windows to: {out2}")
        print(f"     X_train={X_train.shape}  y_train={y_train.shape}  X_val={X_val.shape}  y_val={y_val.shape}")
    else:
        print("[info] Only one timestep; skipped windowing. Downstream training needs T > seq_len.")


def main():
    p = argparse.ArgumentParser(description="Preprocess ERA5 NetCDF/NetCDF4 into npz + train/val windows.")
    p.add_argument("--input", required=True, help="Path to .nc/.nc4 (NetCDF4/HDF5)")
    p.add_argument("--output", required=True, help="Output .npz for raw series")
    p.add_argument("--seq_len", type=int, default=5, help="Input sequence length for windows")
    p.add_argument("--engine", type=str, default=None, help="Force xarray engine (netcdf4/scipy). Leave empty to auto.")
    p.add_argument("--var", type=str, default=None, help="Variable name in the file (e.g., t2m). If omitted, pick first numeric 2D/3D var.")
    args = p.parse_args()

    preprocess_era5(args.input, args.output, seq_len=args.seq_len, var_name=args.var, engine=args.engine)


if __name__ == "__main__":
    main()
