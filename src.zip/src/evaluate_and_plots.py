import argparse, os
import numpy as np
import matplotlib.pyplot as plt

def metrics(y_pred, y_true, eps=1e-9):
    # flatten over H,W, compute per-sample then average
    B = y_true.shape[0]
    p = y_pred.reshape(B,-1); t = y_true.reshape(B,-1)
    rmse = np.sqrt(((p-t)**2).mean(axis=1)).mean()
    mae  = np.abs(p-t).mean(axis=1).mean()
    # corr
    p0 = p - p.mean(axis=1, keepdims=True)
    t0 = t - t.mean(axis=1, keepdims=True)
    corr = (p0*t0).sum(axis=1) / (np.sqrt((p0**2).sum(axis=1))+eps) / (np.sqrt((t0**2).sum(axis=1))+eps)
    corr = corr.mean()
    return rmse, mae, corr

def reliability_curve(y_std, y_err, n_bins=10):
    # fraction of pixels with |err| <= k*std aggregated bin-wise
    bins = np.linspace(0, np.percentile(y_std, 99), n_bins+1)
    xs, ys = [], []
    for i in range(n_bins):
        m = (y_std>=bins[i]) & (y_std<bins[i+1])
        if m.sum()==0: continue
        frac = (np.abs(y_err[m]) <= y_std[m]).mean()
        xs.append(0.5*(bins[i]+bins[i+1])); ys.append(frac)
    return np.array(xs), np.array(ys)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", default="data_processed/preds_mean_std_conv_nll.npz")
    ap.add_argument("--down_to", type=int, default=0, help="Optionally downsample both preds and truth to NxN before metrics (e.g., 64 or 32).")
    args = ap.parse_args()

    print("Using predictions from:", args.pred)
    d = np.load(args.pred)
    y_pred = d["y_pred"]; y_std = d["y_std"]; y_true = d["y_true"]
    print("Shapes -> y_pred:", y_pred.shape, "y_std:", y_std.shape, "y_true:", y_true.shape)

    if args.down_to and args.down_to>0:
        import cv2
        def rs(imgs):
            out = []
            for im in imgs:
                out.append(cv2.resize(im, (args.down_to,args.down_to), interpolation=cv2.INTER_AREA))
            return np.stack(out,0)
        try:
            y_pred = rs(y_pred); y_true = rs(y_true); y_std = rs(y_std)
            print(f"[eval] downsampled all to {args.down_to}×{args.down_to} for metrics.")
        except Exception:
            # Fallback: average-pooling with numpy (no cv2)
            def block_reduce(arr, f):
                H,W = arr.shape
                sh = (args.down_to, H//args.down_to, args.down_to, W//args.down_to)
                arr = arr[:sh[1]*sh[3], :sh[1]*sh[3]]
                return arr.reshape(sh).mean(axis=(1,3))
            y_pred = np.stack([block_reduce(im, np.mean) for im in y_pred],0)
            y_true = np.stack([block_reduce(im, np.mean) for im in y_true],0)
            y_std  = np.stack([block_reduce(im, np.mean) for im in y_std ],0)
            print(f"[eval] coarse pooled to {args.down_to}×{args.down_to} for metrics.")

    rmse, mae, corr = metrics(y_pred, y_true)
    err = y_pred - y_true
    within = (np.abs(err) <= y_std).mean()*100.0
    avg_std = y_std.mean()
    truth_std = y_true.std()
    # simple climatology (mean=0 in z-score space): skill = 1 - MSE(model)/MSE(clim)
    mse_model = ((y_pred - y_true)**2).mean()
    mse_clim  = (y_true**2).mean()
    skill = 100.0*(1.0 - mse_model/max(mse_clim,1e-9))

    print(f"RMSE (z-score): {rmse:.4f}")
    print(f"MAE  (z-score): {mae:.4f}")
    print(f"Correlation     : {corr:.4f}  ({corr*100:.2f}%)")
    print(f"Within-tolerance accuracy (±1σ of truth): {within:.2f}%")
    print(f"Average predictive std: {avg_std:.4f}")
    print(f"Truth std (z-score space): {truth_std:.4f}")
    print(f"Skill vs climatology (MSE): {skill:.2f}%")

    # Reliability curve
    xs, ys = reliability_curve(y_std, err)
    if len(xs)>2:
        os.makedirs("figures", exist_ok=True)
        plt.figure()
        plt.plot(xs, ys, marker='o')
        plt.xlabel("Predicted σ bin center")
        plt.ylabel("P(|error| ≤ σ)")
        plt.title("Reliability curve (ideal ≈ 0.68)")
        plt.grid(True, alpha=0.3)
        out = os.path.join("figures","reliability_curve.png")
        plt.savefig(out, dpi=140, bbox_inches="tight")
        print("Saved:", out)
    else:
        print("Skipped reliability curve (insufficient variation in σ).")

if __name__=="__main__":
    main()
